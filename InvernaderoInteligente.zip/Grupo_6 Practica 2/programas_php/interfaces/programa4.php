<?php
include "conexion.php";  // Conexi�n tiene la informaci�n sobre la conexi�n de la base de datos.

// LAs siguientes son l�neas de c�digo HTML simple, para crear una p�gina web
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 	Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
  <html>
    <head>
      <title> DATOS MAXIMOS, INVERNADERO AUTOMATIZDO # 1
		  </title>
    </head>
    <body>
      <table width="80%" align=center cellpadding=5 border=1 bgcolor="#FFFFFF">
    	 <tr>
         <td valign="top" align=center width=80& colspan=6 bgcolor="green"">
           <img src="img/invernadero.jpg" width=800 height=250>
         </td>
 	     </tr>
 	     <tr>
         <td valign="top" align=center width=80& colspan=6 bgcolor="green"">
           <h1> <font color=white>Consulta y modifica datos MAXIMOS, INVERNADERO AUTOMATIZADO # 1</font></h1>
         </td>
 	     </tr>
<?php

 if ((isset($_POST["enviado"])))  // Ingresa a este if si el formulario ha sido enviado..., al ingresar actualiza los datos ingresados en el formulario, en la base de datos.
   {
   $enviado = $_POST["enviado"];
   if ($enviado == "S1")
    {
          $temp_max = $_POST["temp_max"];  // en estas variables se almacenan los datos de fechas recibidos del formulario HTML inicial
          $hum_max = $_POST["hum_max"];
          $temp_min = $_POST["temp_min"];
          $hum_min = $_POST["hum_min"];
          $damp_min = $_POST["damp_min"];
          
          $mysqli = new mysqli($host, $user, $pw, $db); // Aqu� se hace la conexi�n a la base de datos.
          // la siguiente linea almacena en una variable denominada sql1, la consulta en lenguaje SQL que quiero realizar a la base de datos. 
          // se actualiza la tabla de valores m�ximos
          $sql1 = "UPDATE data_limits set valor='$temp_max' where id=1";  
          echo "sql1...".$sql1;
          // la siguiente l�nea ejecuta la consulta guardada en la variable sql1, con ayuda del objeto de conexi�n a la base de datos mysqli
          $result1 = $mysqli->query($sql1);

          $sql2 = "UPDATE data_limits set valor='$hum_max' where id=3"; 
          // la siguiente l�nea ejecuta la consulta guardada en la variable sql1, con ayuda del objeto de conexi�n a la base de datos mysqli
          echo "sql2...".$sql2;
          $result2 = $mysqli->query($sql2);

          $sql3 = "UPDATE data_limits set valor='$temp_min' where id=2";  
          echo "sql1...".$sql3;
          // la siguiente l�nea ejecuta la consulta guardada en la variable sql1, con ayuda del objeto de conexi�n a la base de datos mysqli
          $result3 = $mysqli->query($sql3);

          $sql4 = "UPDATE data_limits set valor='$hum_min' where id=4"; 
          // la siguiente l�nea ejecuta la consulta guardada en la variable sql1, con ayuda del objeto de conexi�n a la base de datos mysqli
          echo "sql2...".$sql4;
          $result4 = $mysqli->query($sql4);

          $sql5 = "UPDATE data_limits set valor='$damp_min' where id=5";  
          echo "sql1...".$sql5;
          // la siguiente l�nea ejecuta la consulta guardada en la variable sql1, con ayuda del objeto de conexi�n a la base de datos mysqli
          $result5 = $mysqli->query($sql5);

          if (($result1 == 1)&&($result2 == 1)&&($result3 == 1)&&($result4 == 1)&&($result5 == 1))
             $mensaje = "Datos actualizados correctamente";
          else
             $mensaje = "Inconveniente actualizando datos";
   
          //header('Location: programa4.php?mensaje='.$mensaje);

    } // FIN DEL IF, si ya se han recibido los datos del formulario
   }  // FIN DEL IF, si la variable enviado existe, que es cuando ya se env�o el formulario
  
// AQUI CONSULTA LOS VALORES ACTUALES DE HUMEDAD y TEMPERATURA, PARA PRESENTARLOS EN EL FORMULARIO

// CONSULTA TEMPERATURA MAXIMA
$mysqli = new mysqli($host, $user, $pw, $db); // Aqu� se hace la conexi�n a la base de datos.
$sql1 = "SELECT * from data_limits where id=1"; 
// la siguiente l�nea ejecuta la consulta guardada en la variable sql, con ayuda del objeto de conexi�n a la base de datos mysqli
$result1 = $mysqli->query($sql1);
$row1 = $result1->fetch_array(MYSQLI_NUM);
$temp_max = $row1[2];  

// CONSULTA HUMEDAD MAXIMA
$sql2 = "SELECT * from data_limits where id=3"; 
// la siguiente l�nea ejecuta la consulta guardada en la variable sql, con ayuda del objeto de conexi�n a la base de datos mysqli
$result2 = $mysqli->query($sql2);
$row2 = $result2->fetch_array(MYSQLI_NUM);
$hum_max = $row2[2];  

// CONSULTA TEMPERATURA MÍNIMA
$mysqli = new mysqli($host, $user, $pw, $db); // Aqu� se hace la conexi�n a la base de datos.
$sql3 = "SELECT * from data_limits where id=2"; 
// la siguiente l�nea ejecuta la consulta guardada en la variable sql, con ayuda del objeto de conexi�n a la base de datos mysqli
$result3 = $mysqli->query($sql3);
$row3 = $result3->fetch_array(MYSQLI_NUM);
$temp_min = $row3[2];  

// CONSULTA HUMEDAD MÍNIMA
$sql4 = "SELECT * from data_limits where id=4"; 
// la siguiente l�nea ejecuta la consulta guardada en la variable sql, con ayuda del objeto de conexi�n a la base de datos mysqli
$result4 = $mysqli->query($sql4);
$row4 = $result4->fetch_array(MYSQLI_NUM);
$hum_min = $row4[2];  

// CONSULTA HUMEDAD DE LA TIERRA MÍNIMA
$sql5 = "SELECT * from data_limits where id=5"; 
// la siguiente l�nea ejecuta la consulta guardada en la variable sql, con ayuda del objeto de conexi�n a la base de datos mysqli
$result5 = $mysqli->query($sql5);
$row5 = $result5->fetch_array(MYSQLI_NUM);
$damp_min = $row5[2];  

if ((isset($_GET["mensaje"])))
   {
   $mensaje = $_GET["mensaje"];
 	 echo '<tr>	
      		<td bgcolor="#EEEEFF" align=center colspan=2> 
			   	  <font FACE="arial" SIZE=2 color="#000044"> <b>'.$mensaje.'</b></font>  
				  </td>	
	     </tr>';
   }
?>    

     <form method=POST action="programa4.php">
 	     <tr>	
      		<td bgcolor="#CCEECC" align=center> 
			   	  <font FACE="arial" SIZE=2 color="#000044"> <b>Valor M�ximo Temperatura: </b></font>  
				  </td>	
				  <td bgcolor="#EEEEEE" align=center> 
				    <input type="number" name="temp_max" value="<?php echo $row1[2]; ?>" required>  
          </td>	
	     </tr>
 	     <tr>	
      		<td bgcolor="#CCEECC" align=center> 
			   	  <font FACE="arial" SIZE=2 color="#000044"> <b>Valor M�ximo Humedad: </b></font>  
				  </td>	
				  <td bgcolor="#EEEEEE" align=center> 
				    <input type="number" name="hum_max" value="<?php echo $hum_max; ?>" required>  
          </td>	
	     </tr>
       <tr>	
      		<td bgcolor="#CCEECC" align=center> 
			   	  <font FACE="arial" SIZE=2 color="#000044"> <b>Valor Mínimo Temperatura: </b></font>  
				  </td>	
				  <td bgcolor="#EEEEEE" align=center> 
				    <input type="number" name="temp_min" value="<?php echo $temp_min; ?>" required>  
          </td>	
	     </tr>
       <tr>	
      		<td bgcolor="#CCEECC" align=center> 
			   	  <font FACE="arial" SIZE=2 color="#000044"> <b>Valor Mínimo Humedad: </b></font>  
				  </td>	
				  <td bgcolor="#EEEEEE" align=center> 
				    <input type="number" name="hum_min" value="<?php echo $hum_min; ?>" required>  
          </td>	
	     </tr>
       <tr>	
      		<td bgcolor="#CCEECC" align=center> 
			   	  <font FACE="arial" SIZE=2 color="#000044"> <b>Valor Mínimo Humedad Tierra: </b></font>  
				  </td>	
				  <td bgcolor="#EEEEEE" align=center> 
				    <input type="number" name="damp_min" value="<?php echo $damp_min; ?>" required>  
          </td>	
	     </tr>
       <tr>	
				  <td bgcolor="#EEEEEE" align=center colspan=2> 
				    <input type="hidden" name="enviado" value="S1">  
				    <input type="submit" value="Actualizar" name="Actualizar">  
          </td>	
	     </tr>
      </form>	  

       </table>
     </body>
   </html>