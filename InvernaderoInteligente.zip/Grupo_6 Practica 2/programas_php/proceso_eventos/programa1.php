<?php
include "conexion.php";  // Conexi�n tiene la informaci�n sobre la conexi�n de la base de datos.

/*$temp_max = $_POST["temp_max"]; // el dato de temperatura que se recibe aqu� con GET denominado temperatura, es enviado como parametro en la solicitud que realiza la tarjeta microcontrolada
$temp_min = $_POST["temp_min"];
$hum_max = $_POST["hum_max"]; // el dato de humedad que se recibe aqu� con GET denominado humedad, es enviado como parametro en la solicitud que realiza la tarjeta microcontrolada
$hum_min = $_POST["hum_min"];*/

//$light_min = $_POST["light_min"];

$hum = $_GET["humedad"]; // el dato de humedad que se recibe aqu� con GET denominado humedad, es enviado como parametro en la solicitud que realiza la tarjeta microcontrolada
$temp = $_GET["temperatura"]; // el dato de temperatura que se recibe aqu� con GET denominado temperatura, es enviado como parametro en la solicitud que realiza la tarjeta microcontrolada
$light = $_GET["luz"];
$damp = $_GET["humetierra"];
$rain = $_GET["lluvia"];
$flag = FALSE;

/*$event1 = 1; //Excede temp max
$event2 = 2; //Temp por debajo del min
$event3 = 3; //Excede hum max
$event4 = 4; //Hum por debajo del min
$event7 = 7; //Light por debajo del min
$event8 = 8; //Hay lluvia*/

//$ID_TARJ = $_POST["ID_TARJ"];

$mysqli = new mysqli($host, $user, $pw, $db); // Aqu� se hace la conexi�n a la base de datos.

//date_default_timezone_set('America/Bogota'); // esta l�nea es importante cuando el servidor es REMOTO y est� ubicado en otros pa�ses como USA o Europa. Fija la hora de Colombia para que grabe correctamente el dato de fecha y hora con CURDATE y CURTIME, en la base de datos.

//$fecha = date("Y-m-d");
//$hora = date("h:i:s");

// CONSULTA TEMPERATURA MAXIMA
$mysqli = new mysqli($host, $user, $pw, $db); // Aqu� se hace la conexi�n a la base de datos.
$sql1 = "SELECT * from data_limits where id=1"; 
// la siguiente l�nea ejecuta la consulta guardada en la variable sql, con ayuda del objeto de conexi�n a la base de datos mysqli
$result1 = $mysqli->query($sql1);
$row2 = $result1->fetch_array(MYSQLI_NUM);
$temp_max = $row2[2];

// CONSULTA HUMEDAD MAXIMA
$sql2 = "SELECT * from data_limits where id=3"; 
// la siguiente l�nea ejecuta la consulta guardada en la variable sql, con ayuda del objeto de conexi�n a la base de datos mysqli
$result2 = $mysqli->query($sql2);
$row3 = $result2->fetch_array(MYSQLI_NUM);
$hum_max = $row3[2];

// CONSULTA TEMPERATURA MÍNIMA
$mysqli = new mysqli($host, $user, $pw, $db); // Aqu� se hace la conexi�n a la base de datos.
$sql3 = "SELECT * from data_limits where id=2"; 
// la siguiente l�nea ejecuta la consulta guardada en la variable sql, con ayuda del objeto de conexi�n a la base de datos mysqli
$result3 = $mysqli->query($sql3);
$row4 = $result3->fetch_array(MYSQLI_NUM);
$temp_min = $row4[2];  

// CONSULTA HUMEDAD MÍNIMA
$sql4 = "SELECT * from data_limits where id=4"; 
// la siguiente l�nea ejecuta la consulta guardada en la variable sql, con ayuda del objeto de conexi�n a la base de datos mysqli
$result4 = $mysqli->query($sql4);
$row5 = $result4->fetch_array(MYSQLI_NUM);
$hum_min = $row5[2];

//Condiciones de inserción en la tabla registro de eventos

//Condición de la temperatura

if($temp == 0){
    echo "SENSOR FALLÓ <br/>";
    $flag = TRUE;

}else if($temp > $temp_max){
    $sql5 = "INSERT into event_log (fecha, hora, id_limit, id_event) VALUES (CURDATE(), CURTIME(), 1, 1)";
    echo "Evento registrado, temperatura por encima del máximo <br/>";

    echo "sql5...".$sql5; // Se imprime la cadena sql enviada a la base de datos, se utiliza para depurar el programa php, en caso de alg�n error.
    $result5 = $mysqli->query($sql5);
    echo "result es...".$result5."<br/>"; // Si result es 1, quiere decir que el ingreso a la base de datos fue correcto.

}else if($temp < $temp_min){
    $sql6 = "INSERT into event_log (fecha, hora, id_limit, id_event) VALUES (CURDATE(), CURTIME(), 2, 2)";
    echo "Evento registrado, temperatura por debajo del mínimo <br/>";

    echo "sql6...".$sql6; // Se imprime la cadena sql enviada a la base de datos, se utiliza para depurar el programa php, en caso de alg�n error.
    $result6 = $mysqli->query($sql6);
    echo "result es...".$result6."<br/>"; // Si result es 1, quiere decir que el ingreso a la base de datos fue correcto.
}else{
    echo "La temperatura está bien <br/>";
}


//Condición de la humedad

if($hum == 0){
    echo "SENSOR FALLÓ <br/>";
    $flag = TRUE;
}else if($hum > $hum_max){
    $sql7 = "INSERT into event_log (fecha, hora, id_limit, id_event) VALUES (CURDATE(), CURTIME(), 3, 3)";
    echo "Evento registrado, humedad por encima del máximo <br/>";

    echo "sql7...".$sql7; // Se imprime la cadena sql enviada a la base de datos, se utiliza para depurar el programa php, en caso de alg�n error.
    $result7 = $mysqli->query($sql7);
    echo "result es...".$result7."<br/>"; // Si result es 1, quiere decir que el ingreso a la base de datos fue correcto.

}else if($hum < $hum_min){
    $sql8 = "INSERT into event_log (fecha, hora, id_limit, id_event) VALUES (CURDATE(), CURTIME(), 4, 4)";
    echo "Evento registrado, humedad por debajo del mínimo <br/>";

    echo "sql8...".$sql8; // Se imprime la cadena sql enviada a la base de datos, se utiliza para depurar el programa php, en caso de alg�n error.
    $result8 = $mysqli->query($sql8);
    echo "result es...".$result8."<br/>"; // Si result es 1, quiere decir que el ingreso a la base de datos fue correcto.
}else{
    echo "La humedad está bien <br/>";
    /*$sql10 = "INSERT into measured_data (fecha, hora, temperature, air_humidity, light, dampness, rain) VALUES (CURDATE(), CURTIME(), '$temp','$hum','$light','$damp','$rain')"; // Aqu� se ingresa el valor recibido a la base de datos.

    echo "sql10...".$sql10; // Se imprime la cadena sql enviada a la base de datos, se utiliza para depurar el programa php, en caso de alg�n error.
    $result10 = $mysqli->query($sql10);
    echo "result es...".$result10."<br/>"; // Si result es 1, quiere decir que el ingreso a la base de datos fue correcto.*/
}

if($flag == FALSE){    
    $sql10 = "INSERT into measured_data (fecha, hora, temperature, air_humidity, light, dampness, rain) VALUES (CURDATE(), CURTIME(), '$temp','$hum','$light','$damp','$rain')"; // Aqu� se ingresa el valor recibido a la base de datos.
    echo "sql10...".$sql10; // Se imprime la cadena sql enviada a la base de datos, se utiliza para depurar el programa php, en caso de alg�n error.
    $result10 = $mysqli->query($sql10);
    echo "result es...".$result10."<br/>"; // Si result es 1, quiere decir que el ingreso a la base de datos fue correcto.
}

?>
